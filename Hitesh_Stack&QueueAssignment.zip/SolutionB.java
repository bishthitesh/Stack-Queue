import java.util.LinkedList;
import java.util.Queue;

class SiteStats {
    private String url;
    private int numVisits;

    /**
     * Constructor for the SiteStats class
     * 
     * @param url
     *            String that represents an URL that the user has visited
     * @param numVisits
     *            An int that represents the number of times that the user has
     *            visited the url
     */
    public SiteStats(String url, int numVisits) {
        this.url = url;
        this.numVisits = numVisits;
    }

    /**
     * This method returns the number of times that the user has visited the url.
     * 
     * @return An int that represents the number of times that the user has visited
     *         the url
     */
    public int getNumVisits() {
        return this.numVisits;
    }

    /**
     * This method returns the url that we are currently tracking
     * 
     * @return A String that represents the url that we are currently tracking
     */
    public String getUrl() {
        return this.url;
    }

    /**
     * This method updates the number of times that we have visited the url
     *
     * @param updatedNumVisits
     *          int that represents the number that we want to set numVisits to
     */
    public void setNumVisits(int updatedNumVisits) {
        this.numVisits = updatedNumVisits;
    }

    public String toString() {
        return this.url + " | " + this.numVisits;
    }

}

public class SolutionB {

    private static Queue<SiteStats> sites = new LinkedList<SiteStats>();

    //find index of element which is maximum in queue
    public static int maxIndex(Queue<SiteStats> list,
                               int sortIndex)
    {
        int max_index = -1;
        int max_value = Integer.MIN_VALUE;
        int s = list.size();
        for (int i = 0; i < s; i++)
        {
            SiteStats current = list.peek();
            list.remove();
            if (current.getNumVisits() >= max_value && i <= sortIndex)
            {
                max_index = i;
                max_value = current.getNumVisits();
            }
            list.add(current);
        }
        return max_index;
    }

    // Moves given maximum element to rear of queue
    public static void insertMinToRear(Queue<SiteStats> list,
                                       int max_index)
    {
        SiteStats max_value=new SiteStats("",0);
        int s = list.size();
        for (int i = 0; i < s; i++)
        {
            SiteStats current = list.peek();
            list.poll();
            if (i != max_index)
                list.add(current);
            else
                max_value = current;
        }
        list.add(max_value);
    }

    //sort queue
    public static void sortQueue(Queue<SiteStats> list)
    {
        for(int i = 1; i <= list.size(); i++)
        {
            int max_index = maxIndex(list,list.size() - i);
            insertMinToRear(list, max_index);
        }
    }

    // Main method to list top n visited sites
    public static void listTopVisitedSites(Queue<SiteStats> sites, int n) {
        sortQueue(sites);
        for(int i=0;i<n;i++){
            SiteStats temp=sites.peek();
            sites.remove();
            System.out.println(temp);
            sites.add(temp);
        }
    }

    public static void updateCount(String url) {
        int size=sites.size(),found=0;
        SiteStats recently=new SiteStats("",0);
        for (int i = 0; i < size; i++)
        {
            SiteStats current = sites.peek();
            sites.remove();
            if (!current.getUrl().equals(url))
                sites.add(current);
            else{
                found=1;
                current.setNumVisits(current.getNumVisits()+1);
                recently=current;
            }
        }
        if(found==1)
            sites.add(recently);
        else
            sites.add(new SiteStats(url,1));
    }

    public static void main(String[] args) {
        String[] visitedSites = { "www.google.co.in", "www.google.co.in", "www.facebook.com", "www.upgrad.com", "www.google.co.in", "www.youtube.com",
                "www.facebook.com", "www.upgrad.com", "www.facebook.com", "www.google.co.in", "www.microsoft.com", "www.9gag.com", "www.netflix.com",
                "www.netflix.com", "www.9gag.com", "www.microsoft.com", "www.amazon.com", "www.amazon.com", "www.uber.com", "www.amazon.com",
                "www.microsoft.com", "www.upgrad.com" };

        for (String url : visitedSites) {
            updateCount(url);
        }
        listTopVisitedSites(sites, 5);

    }

}
